---
title: 增强Nginx安全性自定义版本号显示信息
date: 2017-01-25 12:02:32
update: 2017-01-25 12:02:32
categories: nginx
tags: nginx
---

* 增强web服务器的安全性
* 1.对Nginx服务器进行版本号的隐藏；
* 2.直接修改nginx的源代码文件参数隐藏Nginx的显示信息；
<!-- more -->

## 基础准备
[root@node1 ~]# yum install -y make gcc pcre-devel zlib-devel
[root@node1 ~]# wget http://nginx.org/download/nginx-1.11.8.tar.gz
[root@node1 ~]# tar zxf nginx-1.11.8.tar.gz



## 隐藏版本号
``` bash
[root@node1 nginx]# pwd
/usr/local/nginx
[root@node1 nginx]# vim conf/nginx.conf
.......
events {
    worker_connections  1024;
}


http {
    include       mime.types;
    default_type  application/octet-stream;
    server_tokens off;   # 不发送版本号--> 新增
    #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
    #                  '$status $body_bytes_sent "$http_referer" '
    #                  '"$http_user_agent" "$http_x_forwarded_for"';

    #access_log  logs/access.log  main;

    sendfile        on;
.........

[root@node1 nginx]# ./sbin/nginx -t
nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok
nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful
启动：
[root@node1 nginx]# ./sbin/nginx 
重新加载配置：
[root@node1 nginx]# ./sbin/nginx -s reload 


```
![](http://ok6h8mla5.bkt.clouddn.com/nginx01.jpg)




## 自定义版本信息
### 修改ngx_http_header_filter_module.c文件

``` bash
[root@node1 nginx-1.11.8]# pwd
/root/nginx-1.11.8
[root@node1 nginx-1.11.8]# vim src/http/ngx_http_header_filter_module.c

......
#static char ngx_http_server_string[] = "Server: nginx" CRLF;  # 默认字段

static char ngx_http_server_string[] = "Server: JWS" CRLF;  # 修改为 JWS
static char ngx_http_server_full_string[] = "Server: " NGINX_VER CRLF;
......
```

### 修改nginx.h文件
``` bash
[root@node1 nginx-1.11.8]# vim src/core/nginx.h
# 默认字段
#define nginx_version      1001108   
#define NGINX_VERSION      "1.11.8"   
#define NGINX_VER          "nginx/" NGINX_VERSION
.....
.....
#define NGINX_VAR          "NGINX"


# 自定义
#define nginx_version      10990119   
#define NGINX_VERSION      "0.10.1"   
#define NGINX_VER          "JWS/" NGINX_VERSION
.....
.....
#define NGINX_VAR          "JWS"

```

### 重新编译
``` bash
[root@node1 nginx-1.11.8]# ./configure --prefix=/usr/local/nginx
[root@node1 nginx-1.11.8]# make && make install

## 关闭之前运行的Nginx进程
## 重新启动nginx
[root@node1 nginx]# ./sbin/nginx

```
![](http://ok6h8mla5.bkt.clouddn.com/nginx02.jpg)

