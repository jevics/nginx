---
title: Hadoop 集群 Hive 基础配置
date: 2017-02-14 22:26:55
update: 2017-02-14 22:26:55
categories: hadoop 
tags: hive
---

## 准备配置环境 Java Hadoop MySQL 
<!--more -->

## JAVA 环境
``` bash
[root@node2 ~]# vim /etc/profile
export JAVA_HOME=/opt/jdk
export PATH=$JAVA_HOME/bin:$PATH
[root@node2 ~]# source /etc/profile
[root@node2 ~]# java -version
java version "1.8.0_111"
Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, mixed mode)

```

## Hadoop(伪分布式环境)

```bash
[root@node2 ~]# useradd hadoop
[root@node2 ~]# tar zxf hadoop-2.7.2.tar.gz -C /opt/source/
[root@node2 ~]# ln -s /opt/source/hadoop-2.7.2 /opt/hadoop
[root@node2 ~]# chown hadoop:hadoop /opt/source/hadoop-2.7.2/ -R
[root@node2 ~]# cat /etc/proflie
export JAVA_HOME=/opt/jdk
export PATH=$JAVA_HOME/bin:$PATH
export HADOOP_HOME=/opt/hadoop
export PATH=$PATH:$HADOOP_HOME/bin
[root@node2 ~]# source /etc/profile

[root@node2 ~]# cd /opt/hadoop
[root@node2 ~]# su - hadoop
[hadoop@node2 ~]$ cd /opt/hadoop/ && vim etc/hadoop/core-site.xml 
<configuration>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>file:/home/hadoop/tmp</value>
        <description>Abase for other temporary directories.</description>
    </property>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://node2:9000</value>
    </property>
</configuration>

[hadoop@node2 hadoop]$ vim etc/hadoop/hdfs-site.xml
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>file:/home/hadoop/tmp/dfs/name</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>file:/home/hadoop/tmp/dfs/data</value>
    </property>
</configuration>

[hadoop@node2 hadoop]$ cat etc/hadoop/slaves
node2

```
* 启动Hadoop
``` bash
* 格式化【首次运行】
[hadoop@node2 hadoop]$ hadoop namenode -format
* 启动
[hadoop@node2 hadoop]$ ./sbin/start-dfs.sh
```

## MySQL 安装配置 
* `YUM 源`: https://dev.mysql.com/downloads/repo/yum/

``` bash
[root@node2 ~]# rpm -ivh mysql57-community-release-el7-9.noarch.rpm
[root@node2 ~]# yum install -y mysql-server
[root@node2 ~]# vim /etc/my.cnf [添加utf8设置]
character_set_server=utf8
[root@node2 ~]# systemctl start mysqld
[root@node2 ~]# systemctl enable mysqld

[root@node2 ~]# grep 'root@localhost' /var/log/mysqld.log
[Note] A temporary password is generated for root@localhost: /#t:lDBq%008

[root@node2 ~]# mysql -uroot -hlocalhost -p'/#t:lDBq%008'
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 1967
Server version: 5.7.17 MySQL Community Server (GPL)

Copyright (c) 2000, 2016, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> set password for 'root'@'localhost'=password('Pass@123');
mysql> create database hive;
mysql> grant all on *.* to hive@'%' identified by 'hive';
mysql> flush privileges;


```

## Hive 安装配置
* [下载 mysql-connector-java](https://dev.mysql.com/downloads/connector/j/) 

``` bash
[root@node2 ~]# wget http://mirrors.hust.edu.cn/apache/hive/hive-1.2.1/apache-hive-1.2.1-bin.tar.gz
[root@node2 ~]# tar zxf apache-hive-1.2.1-bin.tar.gz -C /opt/source/
[root@node2 ~]# ln -s /opt/source/apache-hive-1.2.1-bin /opt/hive/

[root@node2 ~]# cp mysql-connector-java-5.1.40-bin.jar /opt/hive/lib

[root@node2 ~]# chown hadoop:hadoop /opt/source/apache-hive-1.2.1-bin/ -R
[root@node2 ~]# cat /etc/proflie
export JAVA_HOME=/opt/jdk
export PATH=$JAVA_HOME/bin:$PATH
export HADOOP_HOME=/opt/hadoop
export HIVE_HOME=/opt/hive
export PATH=$PATH:$HADOOP_HOME/bin:$HIVE_HOME/bin
[root@node2 ~]# source /etc/profile

```

* 切到hadoop 用户
* hive-site.xml 默认没有手动创建即可

``` bash
[hadoop@node2 hive]$ vim conf/hive-site.xml
....
<configuration>
  <property>
    <name>hive.metastore.warehouse.dir</name>
    <value>/user/hive/warehouse</value>
    <description>location of default database for the warehouse</description>
  </property>
  <property>
    <name>javax.jdo.option.ConnectionURL</name>
    <value>jdbc:mysql://192.168.3.174:3306/hive?createDatabaseIfNotExist=true</value>
    <description>JDBC connect string for a JDBC metastore</description>
  </property>
  <property>
    <name>javax.jdo.option.ConnectionDriverName</name>
    <value>com.mysql.jdbc.Driver</value>
    <description>Driver class name for a JDBC metastore</description>
  </property>
  <property>
    <name>javax.jdo.option.ConnectionUserName</name>
    <value>hive</value>
    <description>username to use against metastore database</description>
  </property>
  <property>
    <name>javax.jdo.option.ConnectionPassword</name>
    <value>hive</value>
    <description>password to use against metastore database</description>
  </property>
</configuration>
```
`说明` :
* hive.metasotre.warehous.dir 当Hadoop配置为伪分布式或分布式环境下会默认任务是HDFS系统中的路径
* 参见 hive编程指南 第二章-----基础操作

``` bash
[hadoop@node2 hive]$ vim conf/hive-env.sh
export JAVA_HOME=/opt/jdk

# Set HADOOP_HOME to point to a specific hadoop install directory
# HADOOP_HOME=${bin}/../../hadoop
HADOOP_HOME=/opt/hadoop
# Hive Configuration Directory can be controlled by:
# export HIVE_CONF_DIR=
export HIVE_CONF_DIR=/opt/hive/conf
# Folder containing extra ibraries required for hive compilation/execution can be controlled by:
# export HIVE_AUX_JARS_PATH=
export HIVE_AUX_JARS_PATH=/opt/hive/lib

```

* [创建Hadoop 目录](https://cwiki.apache.org/confluence/display/Hive/GettingStarted)

``` bash
[hadoop@node2 ~]$ hadoop fs -mkdir /tmp
[hadoop@node2 ~]$ hadoop fs -mkdir -p /user/hive/warehouse
[hadoop@node2 ~]$ hadoop fs -chmod 775 /user/hive/warehouse
[hadoop@node2 ~]$ hadoop fs -chmod 775 /tmp


```

* 使用hive CLI
``` bash
[hadoop@node2 ~]$ hive
Logging initialized using configuration in jar:file:/opt/source/apache-hive-1.2.1-bin/lib/hive-common-1.2.1.jar!/hive-log4j.properties
hive> create database test002;
OK
Time taken: 0.816 seconds
hive> use test002;
OK
Time taken: 0.035 seconds
hive> create table nameid(id int);
OK
Time taken: 0.303 seconds
hive> show databases;
OK
default
src
test002
Time taken: 0.131 seconds, Fetched: 3 row(s)
hive> use test002;
OK
Time taken: 0.037 seconds
hive> show tables;
OK
nameid
Time taken: 0.032 seconds, Fetched: 1 row(s)
hive> 
```
* 查看HDFS 目录
![](http://ok6h8mla5.bkt.clouddn.com/hive01.jpg)


* 启动Hive metastore 服务端
``` bash
[hadoop@node2 ~]$ hive --service metastore
[hadoop@node2 ~]$ jps
[hadoop@node2 ~]$ jps
2576 DataNode
2743 SecondaryNameNode
4298 RunJar  多了此进程
2447 NameNode
5775 Jps
```

* hive 客户端连接
``` bash
编辑配置文件
[hadoops@impala1 hive]$ vi hive-site.xml
<configuration>
    <property>  
		<name>hive.metastore.uris</name>  
	<value>thrift://hadoop-master:9083</value>  
	</property>
</configuration>
[hadoops@impala1 hive]$ hive
Logging initialized using configuration in jar:file:/home/workdir/source/apache-hive-1.2.1-bin/lib/hive-common-1.2.1.jar!/hive-log4j.properties
hive> show databases;
OK
default
src
Time taken: 1.189 seconds, Fetched: 2 row(s)
hive> 

```

## 参考资料
[1] https://cwiki.apache.org/confluence/display/Hive/GettingStarted
[2] Hive 编程指南
[3] http://nunknown.com/study/282/#5

