---
title: python 请求API获取数据
date: 2017-07-21 09:05:52
update: 2017-07-21 09:05:52
categories: Python
tags: Python
---

获取API数据示例
<!-- more -->

## 示例1
``` python
#!/usr/bin/python
# coding: utf-8
import urllib2
import hashlib
import datetime,time
import json

Api = "http://api.test.com/test/api/data?value=1"
Domain = "test.web.com"
api = "/api/test/get"
apiKey = "12dfsd2333dfsdf90843nkdhfsd"

times1 = (datetime.datetime.now() - datetime.timedelta(minutes = 3))
times2 = time.strptime(times1.ctime(), "%a %b %d %H:%M:%S %Y")
##
Times = time.strftime("%Y%m%d-%H%M",times2)
TimesBw = time.strftime("%Y-%m-%d %H:%M",times2)
NowTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
##
ts = str(time.mktime(time.strptime(Times,"%Y%m%d-%H%M"))).split('.')[0]
##
ApiStr = "%s%s%s" % (api,ts,apiKey)
sumKey = hashlib.md5()
sumKey.update(ApiStr)
Signing = sumKey.hexdigest()

key1 = Domain
key2 = "endtime=%s" % Times
key3 = "starttime=%s" % Times
key4 = "stat_time=1min"
key5 = "unit=bps"
key6 = "ts=%s" % ts

URL = "%s&%s&%s&%s&%s&%s&%s" % (Api,key1,key2,key3,key4,key5,key6)
print "curl -v -H '%s:%s' %s " % ('x-console-api-signature',Signing,URL)

req = urllib2.Request(URL)
req.add_header('x-console-api-signature',Signing)
response = urllib2.urlopen(req)
Datas = response.read()

codes = json.loads(Datas)
nums = codes.get('data')[0].get('bandwidth').get(TimesBw)

if nums > 0:
    print "ok %s" % nums
else:
    print "error"

```

## 示例2
```
#!/usr/bin/python
# coding: utf-8

import urllib2
import hashlib
import datetime,time
import json
import sys

api = "http://api.baidu.com/get/api"
users = "test@baidu.com"
domains = "www.baidu.com"
api_key = "8dfjk9zcvcnuwheiufhd8"
api_pwd = "626aad90c2dfdfad5a61"
logs = '/tmp/api.log'
#
Nows = datetime.datetime.now()
times1 = ( Nows - datetime.timedelta(minutes = 30))
start_days = times1.strftime("%Y-%m-%d")
start_times = times1.strftime("%H:%M")
timestamp = times1.strftime("%Y%m%d-%H%M")
days = Nows.strftime("%Y%m%d")
NowTime = Nows.strftime("%Y-%m-%d %H:%M:%S")
ts = str(time.mktime(time.strptime(timestamp,"%Y%m%d-%H%M"))).split('.')[0]
#ts = "1499997000"
# 
sumstr = "%s%s%s%s" % (days,users,api_key,api_pwd,)
sumKey = hashlib.md5()
sumKey.update(sumstr)
Signing = sumKey.hexdigest()
#
URL = "%sp=%s&u=%s&sdt=basd&dhost=%s&start=%s %s&time=%s %s" % (api,Signing,users,domains,start_days,start_times,start_days,start_times)
print URL
#
Files = open(logs,'a+')
#
def CheckURL(Datas):
    try:
        codes = dict(json.loads(Datas))
        dlist = codes.get('data').get(ts).get(domains)[0]
        nums = dlist[2]
        if nums > 0:
           Files.write("[%s] %s %s {%s} ok\n" % (NowTime,start_days,start_times,dlist))
        else:
           Files.write("[%s] nums: %s null\n" % (NowTime,nums))
    except Exception,error:
        print "[%s] %s %s error %s" % (NowTime,start_days,start_times,error)
        Files.write("[%s] %s %s error %s --> %s\n" % (NowTime,start_days,start_times,error,codes))

def main():
    try:
        req = urllib2.Request(URL)
        response = urllib2.urlopen(req,timeout=20)
        Datas = response.read()
        CheckURL(Datas)
    except Exception,e:
        print e
        Files.write(e)   
    Files.close()


if __name__ == '__main__':
    main()


```
