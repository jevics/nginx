---
title: shell脚本实现文件同步
date: 2017-01-23 16:09:43
update: 2017-01-23 16:09:43
categories: shell
tags: shell
---


# 文件同步
## 需要配置ssh 双机免密互信
<!-- more -->

## 目录文件结构
``` bash
$ pwd && ls
/home/test-shell
config			docscluster.sh	fileupdate.sh
$ tree -r
.
├── fileupdate.sh
├── docscluster.sh
└── config
    └── config.sh

```

## 脚本内容
``` bash

$ cat docscluster.sh
#!/bin/bash
basedir=`dirname $0`
comond=$*
source $basedir/config/config.sh
for each_ip in $command_ips
do
	echo ""
	echo ""
	echo -e "\033[33m============Remote Command Execution：$each_ip======================\033[0m"
	ssh -p $port $each_ip "$comond"
done

echo -e "\033[32m+++++++++++++++finished!!!+++++++++++++++++\033[0m"


$ cat fileupdate.sh
#!/bin/bash
basedir=$(dirname $0)
source $basedir/config/config.sh
dir=$(dirname $1)
if [ "$dir" == "." ]
then
    dir=$PWD
fi
echo "file dir is $dir"
for each_ip in $file_ips
do
	echo ""
	echo ""
	echo -e "\033[31m==================starting rsync file $1 to $each_ip=====================\033[0m"
	ssh $each_ip -p $port "cd $dir" 2>/dev/null
	if [ $? -eq 0 ]
	then
		echo "remote dir is existed!"
	else
		echo "remote dir is not exist,create it."
		ssh $each_ip -p $port "mkdir -p $dir"
	fi
	rsync -var "-e ssh -p $port" $1 ${each_ip}:/${dir}/
done

echo -e "\033[32m*****************finished!!!*******************\033[0m"

配置文件
$ cat config/config.sh
#!/bin/bash
file_ips="host1 host2 host3 host4 host5 host6"
command_ips="localhost $file_ips"
port=22



```
## 示例
- $ cd /home/t-shell
- $ ./fileupdate.sh /opt/config/test.sh

将自动同步各主机/opt/config/test.sh 文件
