---
title: Python FTP模块
date: 2017-07-21 08:04:21
update: 2017-07-21 08:04:21
categories: Python
tags: Python
---

Python FTP 模块简介
<!-- more -->

``` python
#!/usr/bin/python
# coding: utf-8
from ftplib import FTP


def ftpconnect():
    ftpServer = '192.168.1.1'
    username = 'admin'
    password = 'password'
    ftp = FTP()
    ftp.set_debuglevel(2)
    ftp.connect(ftpServer,21)
    ftp.login(username,password)
    ftp.set_pasv(False)
    return ftp

def MsFtp ():
    try:
        ftp.connect('192.168.1.1')
        ftp.login('admin', 'password', '-p')
        ftp.set_pasv(False)
        ftp.dir('/upload')
        ftp.quit()
    except Exception,e:
        print e

def testDownload():
    try:
        ftp = ftpconnect()
        ftp.dir('/soft/website')
        bufsize = 1024
        localpath = "/Users/jay/PycharmProjects/nodejs.tar.gz"
        remotepath = "/soft/website/nodejs.tar.gz"
        fp = open(localpath, 'wb')
        ftp.retrbinary('RETR ' + remotepath, fp.write, bufsize)
        fp.close()
        ftp.quit()
    except Exception, e:
        print e

def testUpload():
    localpath = "/Users/jay/PycharmProjects/upload.log"
    ftp = ftpconnect()
    bufsize = 1024
    remotepath = '/soft/website/upload.log'
    fp = open(localpath, 'rb')
    ftp.storbinary('STOR ' + remotepath, fp, bufsize)
    ftp.set_debuglevel(0)
    fp.close()
    ftp.quit()

```

[参考链接](http://python.usyiyi.cn/translate/python_278/library/ftplib.html)
