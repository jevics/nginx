---
title: Python urllib模块下载文件
date: 2017-05-16 22:41:08
update: 2017-05-16 22:41:08
categories: Python
tags: Python
---

下载文件
<!-- more -->

# python 下载文件
## 方法一：
``` python
import urllib 
import urllib2 
import requests
print "downloading with urllib" 
url = 'http://www.pythontab.com/test/demo.zip'  
print "downloading with urllib"
urllib.urlretrieve(url, "demo.zip")
```

## 方法二：
``` python
import urllib2
print "downloading with urllib2"
url = 'http://www.pythontab.com/test/demo.zip' 
f = urllib2.urlopen(url) 
data = f.read() 
with open("demo2.zip", "wb") as code:     
    code.write(data)
```

## 方法三：

``` python

import requests 
print "downloading with requests"
url = 'http://www.pythontab.com/test/demo.zip' 
r = requests.get(url) 
with open("demo3.zip", "wb") as code:
     code.write(r.content)
```

* 使用urllib，一条语句即可,可以把urllib2缩写成：

``` python

f = urllib2.urlopen(url) 
with open("demo2.zip", "wb") as code:
   code.write(f.read()) 
   
``` 
