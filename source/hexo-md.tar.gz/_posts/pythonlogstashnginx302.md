---
title: Logstash Monitor Nginx Process 
date: 2017-08-08 17:35:04
update: 2017-08-08 17:35:04
categories: Python
tags: Python
---

- 使用Python写的监控写入es数据的logstash 进程异常状态脚本
- command 命令执行
- pwechat 报警
- logstashMonitor.py 主文件
<!-- more -->

## command.py

```
#!/usr/bin/env python
# coding: utf-8
import paramiko
import threading
import sys

def SSH2(ip,cmd):
    hostname = ip
    port = 1111
    username = 'root'
    key_file = '/root/.ssh/id_rsa'
    key = paramiko.RSAKey.from_private_key_file(key_file)
    try:
       s = paramiko.SSHClient()
           s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
       s.connect(hostname,port,username,pkey=key)
       stdin,stdout,stderr = s.exec_command(cmd)
       print stdout.read()
           print "%s\tOK\n" % ip
       s.close()
        except Exception,e:
           print e
           sys.exit(1)

def cmd(ip,cmd):
    threads = []
    Cmd = threading.Thread(target=SSH2,args=(ip,cmd))
    Cmd.start()


```

## pwechat.py

```

#!/usr/bin/python
# coding: utf-8
# Alarm Wechat
#
from urllib import quote
import urllib2
import json,sys

reload(sys)
sys.setdefaultencoding('utf-8')

def wechat(title,content):
        API_ADDR='1.1.1.1:80'
        gnum='team'
        Title = quote(title.encode('utf8'))
        Content = quote(content.encode('utf8'))
        API_URL="http://%s/openwx/send_group_message?displayname=%s&content=%s%s" % (API_ADDR,gnum,Title,Content)
        req = urllib2.Request(API_URL)
        result = urllib2.urlopen(req)
        res = result.read()

def wechat_t2(title,content):
        API_ADDR='1.1.1.1:80'
        gnum = 'team2'
        Title = quote(title.encode('utf8'))
        Content = quote(content.encode('utf8'))
        API_URL="http://%s/openwx/send_group_message?displayname=%s&content=%s%s" % (API_ADDR,gnum,Title,Content)
        req = urllib2.Request(API_URL)
        result = urllib2.urlopen(req)
        res = result.read()
        #salve_info = json.loads(res)


```

## logstashMonitor.py

```
#!/usr/bin/python
# coding: utf-8
from urllib import quote
import urllib2
import json,sys,os
import time,datetime
import pwechat
import command

##
Sdir = os.path.split(os.path.realpath(sys.argv[0]))[0]
os.chdir(Sdir)
##
URL = "http://1.1.1.1:9200/_sql?sql=SELECT%20"
ipList = ['1.1.1.1','2.2.2.2','3.3.3.3']
Monsite = "1.1.1.1"
##
Times1 = datetime.datetime.now()
Nowtimes = str(time.mktime(Times1.timetuple())).split('.')[0]+'000'

Times2 = (datetime.datetime.now() - datetime.timedelta(minutes=30))
Agotimes = str(time.mktime(Times2.timetuple())).split('.')[0]+'000'
##
MonTime = Times1.strftime("%Y-%m-%d %H:%M:%S")
indexTimes = Times1.strftime("%Y.%m.%d")
Index = "ngx-%s" % indexTimes

def AlarmErr():
    title = "title"
    print title
    print content
    pwechat.wechat_dt(title, content)

def QueryCheck(ip):
    QueryURL = " from %s where localhost='%s' and @timestamp>=%s and @timestamp<%s" % (Index,ip,Agotimes,Nowtimes)
    #Sql = quote(sql,safe="_,=")
    query = quote(QueryURL)
    CheckURL = "%s%s%s" % (URL,"count(*)",query)
    #print CheckURL
    global content
    try:
        req = urllib2.Request(CheckURL)
        response = urllib2.urlopen(req)
        Datas = response.read()
        codes = json.loads(Datas)
        nums = codes.get('aggregations').get('COUNT(*)').get('value')
        if nums > 0:
            print "节点: %s Nums: %s" % (ip,nums)
            #sys.exit(0)
        else:
            command.cmd(ip,'sh /opt/logstash/bin/nginx-start.sh')
            content = "\nMonsite: %s\n节点: %s\n时间: %s" % (Monsite,ip,MonTime)
            AlarmErr()
    except Exception,e:
        print e

def main():
    for ip in ipList:
        QueryCheck(ip)

if __name__ == '__main__':
   main()

```
