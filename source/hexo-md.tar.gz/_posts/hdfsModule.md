---
title: Python HDFS操作模块
date: 2017-05-16 22:31:55
update: 2017-05-16 22:31:55
categories: Python
tags: Python
---

Hadoop HDFS 相关模块

<!-- more -->

# HDFS Python模块
## [1] `snakebite`
- [Github](https://github.com/spotify/snakebite)
- [Document](https://snakebite.readthedocs.io/en/latest/client.html)
``` 
# pip install snakebite

```

## [2] `hdfs` 
- [Github](https://github.com/mtth/hdfs)
- [Document](https://hdfscli.readthedocs.io/en/latest/index.html)
- [参考链接](http://blog.csdn.net/gamer_gyt/article/details/52446757)
### pip install hdfs

```
from hdfs import Client
##连接
client = Client('http://192.168.1.254:50070')


##列出目录
client.list('/test/test.gz')


下载:
* download(hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
client.download('/test/test.gz','/tmp')


upload——上传数据:
* upload(hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, chunk_size=65536,progress=None, cleanup=True, **kwargs)
overwrite：是否是覆盖性上传文件
n_threads：启动的线程数目
temp_dir：当overwrite=true时，远程文件一旦存在，则会在上传完之后进行交换
chunk_size：文件上传的大小区间
progress：回调函数来跟踪进度，为每一chunk_size字节。它将传递两个参数，文件上传的路径和传输的字节数。一旦完成，-1将作为第二个参数
cleanup：如果在上传任何文件时发生错误，则删除该文件
##
client.upload("/test","/opt/bigdata/hadoop/NOTICE.txt") 


```
### hdfscli [命令行工具]
- 配置文件
```
# cat .hdfscli.cfg 
[global]
default.alias = dev

[dev.alias]
url = http://192.168.1.254:50070
user = root
root = /test/
[hdfscli-avro.command]
log.level = INFO
log.path = /tmp/hdfscli.log

```
- 示例
```
Usage:
  hdfscli [interactive] [-a ALIAS] [-v...]
  hdfscli download [-fsa ALIAS] [-v...] [-t THREADS] HDFS_PATH LOCAL_PATH
  hdfscli upload [-sa ALIAS] [-v...] [-A | -f] [-t THREADS] LOCAL_PATH HDFS_PATH
  hdfscli -L | -V | -h
  
# hdfscli download -a dev success /tmp/
# hdfscli upload -a dev /mnt/yangjie.py .  ['.'代表上传到配置文件指定的目录下]

```


## [3] `pyhdfs`
- [Github](https://github.com/jingw/pyhdfs)
- [Document](http://pyhdfs.readthedocs.io/en/latest/pyhdfs.html)
### pip install pyhdfs

```
from pyhdfs import HdfsClient

HdfsAddr = '192.168.1.254:50070'
HdfsPath = '/user/test/'
Client = HdfsClient(hosts = '192.168.1.254:50070')

## 列出
Client.list_status('hdfsFilePath')
## 下载
Client.copy_to_local('hdfsPath','localPath')
## 

```

