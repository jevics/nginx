---
title: 日志定时合并任务处理
date: 2017-08-07 18:49:34
update: 2017-08-08 10:29:56
categories: Python
tags: Python
---

日志合并处理
<!-- more -->


```

#!/usr/bin/python
# -*- coding:utf-8 -*-
# use sched to timing
import time
import datetime
import os
import sched
import json
import urllib
import urllib2
import logging
import logging.config
import redis
import math
#import subprocess
#from aliyunsdkcore import client
#from aliyunsdkcdn.request.v20141111 import DescribeCdnDomainLogsRequest
from multiprocessing import Pool

logging.config.fileConfig("/mnt/logs/logger.conf")
logger = logging.getLogger("merlog")

#Schedule = sched.scheduler(time.time, time.sleep)
#Client=client.AcsClient('key','password','endpoint')
DomainName = 'jevic.github.io'
LocalDir = '/log/logs/%s/' %(DomainName)
HdfsDir = ''
HdfsDirAli = '%s' %(DomainName)
HdfsDirMerge = '/%s/' %(DomainName)
RedisKey = 'log_%s' %(DomainName)
#Redis = redis.StrictRedis(host='localhost', port=6379, db=0, password='password')
RedisPool = redis.ConnectionPool(host='localhost', port=6379, db=0, password='password')
Timeout = 60 * 90 #30min timeout

#生成将要处理的任务,记录到redis
def create_job():
  nowTime = datetime.datetime.now()
  tsTemp = int(time.mktime(nowTime.timetuple()))
  ts = tsTemp - tsTemp % 60
  if 0 == (ts % 300):
    redisClient = redis.Redis(connection_pool=RedisPool)
    jobTime = nowTime.strftime('%Y%m%d/%H%M')
    redisClient.hset(RedisKey, jobTime, '0')
    redisClient.shutdown

#转换成对应的文件名(a)
def to_logname_ali(domainName, jobTime):
  jobTimeObj = time.strptime(jobTime, '%Y%m%d/%H%M')
  startTime = time.strftime('%Y_%m_%d_%H%M', jobTimeObj)
  endTime = (datetime.datetime.fromtimestamp(int(time.mktime(jobTimeObj))) + datetime.timedelta(minutes=5)).strftime('%H%M')
  return "%s_%s_%s.gz" %(domainName, startTime, endTime)

#转换成对应的文件名
def to_logname(domainName, jobTime):
  fileTime = time.strftime('%Y_%m_%d_%H%M', time.strptime(jobTime, '%Y%m%d/%H%M'))
  return "%s_%s.gz" %(domainName, fileTime)
  #return "%s_%s_0.gz" %(domainName, fileTime)

 #转换成合并后的文件名
def to_logname_merge(domainName, jobTime):
  fileTime = time.strftime('%Y_%m_%d_%H%M', time.strptime(jobTime, '%Y%m%d/%H%M'))
  return "%s_%s_merge.gz" %(domainName, fileTime)

 #转换成合并后的文件名(合并过程产生的文件)
def to_logname_merge_crc(domainName, jobTime):
  fileTime = time.strftime('%Y_%m_%d_%H%M', time.strptime(jobTime, '%Y%m%d/%H%M'))
  return ".%s_%s_merge.gz.crc" %(domainName, fileTime)

#基于hdfs合并日志文件
def _handle_merge_file(domainName, jobTime, hdfsFileDir0, hdfsFileDir1):
  try:
    localFileCrcDir = "%s%s" %(LocalDir, to_logname_merge_crc(domainName, jobTime))
    localFileDir = "%s%s" %(LocalDir, to_logname_merge(domainName, jobTime))
    hdfsDirPrefix = "%s%s" %(HdfsDirMerge, jobTime)
    mergeHdfsFileDir = "%s/%s" %(hdfsDirPrefix, to_logname_merge(domainName, jobTime))
    hdfsSuccessFileDir = "%s/%s" %(hdfsDirPrefix, "_SUCCESS")

    merge = os.system('hadoop fs -getmerge %s %s %s' %(hdfsFileDir0, hdfsFileDir1, localFileDir))
    mkdir = os.system('hadoop fs -mkdir -p %s' %(hdfsDirPrefix))
    time.sleep(1)
    put = os.system('hadoop fs -put %s %s' %(localFileDir, mergeHdfsFileDir))
    #time.sleep(1)
    ls = os.popen('hadoop fs -ls %s' %(mergeHdfsFileDir))
    time.sleep(1)
    lsmsg = ls.readlines()
    while (not lsmsg):
      ls = os.popen('hadoop fs -ls %s' %(mergeHdfsFileDir))
      time.sleep(1)
      lsmsg = ls.readlines()

    hdfsSize = lsmsg[0].split()[4]
    if '0' != hdfsSize:
      putSuccess = os.system('hadoop fs -touchz %s' %(hdfsSuccessFileDir))
      #time.sleep(1)
      redisClient = redis.Redis(connection_pool=RedisPool)
      redisClient.hdel(RedisKey, jobTime)
      redisClient.shutdown
      os.remove(localFileDir)
      os.remove(localFileCrcDir)

  except Exception,e:
    logger.warn(e)

def copy_hdfs(srcDir, jobTime):
   hdfsDirPrefix = "%s%s" %(HdfsDirMerge, jobTime)
   mergeHdfsFileDir = "%s/%s" %(hdfsDirPrefix, to_logname_merge(DomainName, jobTime))
   copy = os.system('hadoop fs -cp %s %s' %(srcDir, mergeHdfsFileDir))

def success_hdfs(jobTime):
  hdfsDirPrefix = "%s%s" %(HdfsDirMerge, jobTime)
  hdfsSuccessFileDir = "%s/%s" %(hdfsDirPrefix, "_SUCCESS")
  putSuccess = os.system('hadoop fs -touchz %s' %(hdfsSuccessFileDir))

#检查日志是否存在
def _handle_check_hdfs_file(jobTime):
  hdfsFileDir0 = "%s%s/%s" %(HdfsDir, jobTime, to_logname(DomainName, jobTime))
  hdfsFileDir1 = "%s%s/%s" %(HdfsDirAli, jobTime, to_logname_ali(DomainName, jobTime))

  ls0 = os.popen('hadoop fs -ls %s' %(hdfsFileDir0))
  time.sleep(1)
  ls1 = os.popen('hadoop fs -ls %s' %(hdfsFileDir1))
  time.sleep(1)

  lsmsg0 = ls0.readlines()
  lsmsg1 = ls1.readlines()

  if lsmsg0 and lsmsg1:
    _handle_merge_file(DomainName, jobTime, hdfsFileDir0, hdfsFileDir1)
  elif _is_timeout_logs(jobTime):
    hdfsDirPrefix = "%s%s" %(HdfsDirMerge, jobTime)
    mkdir = os.system('hadoop fs -mkdir -p %s' %(hdfsDirPrefix))
    time.sleep(1)

    if lsmsg0:
      copy_hdfs(hdfsFileDir0, jobTime)

    if lsmsg1:
      copy_hdfs(hdfsFileDir1, jobTime)

    success_hdfs(jobTime)
    redisClient = redis.Redis(connection_pool=RedisPool)
    redisClient.hdel(RedisKey, jobTime)
    redisClient.shutdown
  else:
    redisClient = redis.Redis(connection_pool=RedisPool)
    redisClient.hset(RedisKey, jobTime, '0')
    redisClient.shutdown

#判断是否超时的
def _is_timeout_logs(jobTime):
  nowTime = datetime.datetime.now()
  newTs = int(time.mktime(nowTime.timetuple()))
  jobTimeTs = int(time.mktime(time.strptime(jobTime, '%Y%m%d/%H%M')))
  return (Timeout < (newTs - jobTimeTs))

#获取需要处理的任务
def get_jobs():
  try:
    redisClient = redis.Redis(connection_pool=RedisPool)
    handleJobs = redisClient.hgetall(RedisKey)
    jobs = []
    for handleJob in handleJobs:
      if ("0" != handleJobs[handleJob]):
        continue

      if 13 != len(handleJob):
        continue

      jobs.append(handleJob)
      redisClient.hset(RedisKey, handleJob, '1')

    redisClient.shutdown
    return jobs
  except Exception,e:
    logger.warn(e)

#执行任务
def execute_job():
  create_job()
  jobs = get_jobs()

  pool = Pool()
  pool.map(_handle_check_hdfs_file, jobs)
  pool.close()
  pool.join()

if __name__ == '__main__':
  execute_job()

```
