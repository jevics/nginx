---
title: elastic 5.1集群冷热数据分离及插件配置(head,kopf,cerebro)
date: 2017-02-13 18:30:53
update: 2017-02-13 18:30:53
categories: elk
tags: elk
---

elastic 5.1集群冷热数据分离
head 插件支持以及cerebor插件(原2.0的kopf插件)
<!--more-->

## [分片配置过滤设置](https://www.elastic.co/guide/en/elasticsearch/reference/5.2/shard-allocation-filtering.html)：[冷热数据分离]          


``` bash
[es@es5 es]$ vim config/elasticsearch.yml 
cluster.name: test-elk 
node.name: node-1
node.master: true 
node.data: true
path.data: /data1/es/data,/data2/es/datata
path.logs: /home/es/logs
#bootstrap.memory_lock: true 
network.publish_host: es-5
network.bind_host: es-5   
# 集群区域设置
# node.attr.rack_id: zone1
# 冷热集群设置
#node.attr.zone: hot
node.attr.zone: stale
## 集群自动发现设置
discovery.zen.minimum_master_nodes: 2
discovery.zen.ping.unicast.hosts: ["es-5", "es-4", "es-3"]
discovery.zen.fd.ping_timeout: 120s
discovery.zen.fd.ping_retries: 6
discovery.zen.fd.ping_interval: 30s
client.transport.ping_timeout: 60s
discovery.zen.ping_timeout: 120s


cluster.routing.allocation.disk.watermark.low: 90%
cluster.routing.allocation.disk.watermark.high: 5gb

## 关闭x-pack认证
xpack.security.enabled: false
## head 插件支持,具体配置参见链接教程
## https://github.com/mobz/elasticsearch-head
http.cors.enabled: true
http.cors.allow-origin: "*"
http.cors.allow-credentials: true

```

## cerebro 插件 (原kopf插件,功能基本一致)
https://github.com/lmenezes/cerebro
* 配置很简单参照github示例即可，下面给出简要配置

``` bash
[root@es cerebro-0.5.0]# pwd
/workdir/cerebro-0.5.0
[root@es cerebro-0.5.0]# grep 'host' conf/application.conf 
hosts = [
  ....
      host = "http://192.168.1.10:9200" ## es节点
//      url = "ldap://host:port"
[root@es cerebro-0.5.0]# cat start.sh 
#!/bin/bash
#https://github.com/lmenezes/cerebro
#bin/cerebro -Dpidfile.path=/var/run/cerebro
#pidfile.path = "/dev/null"

./bin/cerebro -Dhttp.port=8900 \
-Dhttp.address=192.168.1.10 \
> cerebro.log &

```




