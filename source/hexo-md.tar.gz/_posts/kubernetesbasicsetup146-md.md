---
title: kubernetes基础入门之-安装部署配置示例
date: 2017-01-23 15:51:21
update: 2017-01-23 15:51:21
categories: kubernetes
tags: kubernetes
---

![这里写图片描述](http://kubernetes.io/images/flower.png)
<!-- more -->
## 简介：
* Kubernetes是Google开源的容器集群管理系统，其提供应用部署、维护、 扩展机制等功能，利用Kubernetes能方便地管理跨机器运行容器化的应用，其主要功能如下：

	* 1) 使用Docker对应用程序包装(package)、实例化(instantiate)、运行(run)。

	* 2) 以集群的方式运行、管理跨机器的容器。

	* 3) 解决Docker跨机器容器之间的通讯问题。

	* 4) Kubernetes的自我修复机制使得容器集群总是运行在用户期望的状态。

- 当前Kubernetes支持GCE、vShpere、CoreOS、OpenShift、Azure等平台，除此之外，也可以直接运行在物理机上。

## 本文概述：
###  kubernetes 版本 1.4.6
### 系统环境( CentOS 7.2 )
----

### 环境准备
``` bash
a) # systemctl disable firewalld 
b) # sed -i s'/SELINUX=enforcing/SELINUX=disabled/g' /etc/sysconfig/selinux
c) # yum -y update && reboot
d) # yum -y install ntpdate && ntpdate cn.pool.ntp.org
```
> 分别在各节点写入DNS：
192.168.11.10 master hub.jevic.io
192.168.11.20 node1
192.168.11.30 node2
### 下载安装：
etct: https://github.com/coreos/etcd/releases
flannel: https://github.com/coreos/flannel/releases
kubernetes: https://github.com/kubernetes/kubernetes/releases/
docker: https://docs.docker.com/engine/installation/linux/centos/

----
### Master 配置： 192.168.11.10
``` bash
[root@ master]# ls /opt/sourceetcd
flannel  etcd  kubernetes
[root@ master] ln -s  /opt/source/etcd/etcd /usr/local/bin
[root@ master] ln -s  /opt/source/etcd/etcdctl /usr/local/bin
[root@ master] ln -s  /opt/source/flannel/flanneld /usr/local/bin
[root@ master] ln -s  /opt/source/kubernetes/server/bin/kube-apiserver /usr/local/bin
[root@ master] ln -s  /opt/source/kubernetes/server/bin/kube-controller-manager /usr/local/bin
[root@ master] ln -s  /opt/source/kubernetes/server/bin/kubectl /usr/local/bin
[root@ master] ln -s  /opt/source/kubernetes/server/bin/kube-scheduler /usr/local/bin
[root@ master] mkdir /var/log/{flanneld,kubernetes}

[root@ master] nohup etcd --name etcd10 --data-dir /var/lib/etcd \
--listen-client-urls http://0.0.0.0:2378,http://0.0.0.0:4001 \
--advertise-client-urls http://0.0.0.0:2378,http://0.0.0.0:4001 >> /var/log/etcd.log 2>&1 &

[root@ master] nohup flanneld --listen=0.0.0.0:8888 >> /var/log/flanneld/flanneld.log 2>&1 &

[root@ master] etcdctl set /coreos.com/network/config '{ "Network": "10.1.0.0/16" }'

#### 然后在node1,node2 分别执行(a-g)部分操作


#### 最后开启kubernetes服务：
[root@ master] nohup kube-apiserver --logtostderr=true \
--v=0 --etcd_servers=http://0.0.0.0:2378 \
--insecure-bind-address=0.0.0.0 \
--insecure-port=8080 \
--service-cluster-ip-range=10.254.0.0/16 >> /var/log/kubernetes/kube-apiserver.log 2>&1 &
[root@ master] nohup kube-controller-manager --logtostderr=true --v=0 --master=http://0.0.0.0:8080 >> /var/log/kubernetes/controller.log 2>&1 &
[root@ master] nohup kube-scheduler --logtostderr=true --v=0 --master=http://0.0.0.0:8080 >> /var/log/kubernetes/scheduler.log 2>&1 &


```


----------------------------------------------------
### node1: 192.168.11.20
``` bash
[root@ node1]# ls /opt/source
flannel   kubernetes
[root@ node1]# ln -s /opt/source/etcd/etcd  /usr/local/bin
[root@ node1]# ln -s /opt/source/etcd/etcdctl /usr/local/bin
[root@ node1]# ln -s /opt/source/flannel/flanneld /usr/local/bin
[root@ node1]# ln -s /opt/source/kubernetes/server/bin/kubelet /usr/local/bin
[root@ node1]# ln -s /opt/source/kubernetes/server/bin/kube-proxy /usr/local/bin

a.[root@ node1]# mkdir /var/log/{flanneld,kubernetes}

b.[root@ node1]# nohup flanneld -etcd-endpoints=http://192.168.11.10:4001 -remote=192.168.11.10:8888 >> /var/log/flanneld/flanneld.log 2>&1 &

c.[root@ node1]# source /run/flannel/subnet.env

d.[root@ node1]# cat /run/flannel/subnet.env 
FLANNEL_NETWORK=10.1.0.0/16
FLANNEL_SUBNET=10.1.62.1/24
FLANNEL_MTU=1472
FLANNEL_IPMASQ=false

e.[root@ node1]# grep "bip" /lib/systemd/system/docker.service 
ExecStart=/usr/bin/dockerd --bip=10.1.62.1/24 --mtu=1472

f.[root@ node1]# systemctl daemon-reload && systemctl start docker

g.[root@ node1]# ip a|egrep "docker|flan"
3: flannel0: <POINTOPOINT,MULTICAST,NOARP,UP,LOWER_UP> mtu 1472 qdisc pfifo_fast state UNKNOWN qlen 500
    inet 10.1.62.0/16 scope global flannel0
4: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN 
    inet 10.1.62.1/24 scope global docker0

### 最后启动kubernetes节点服务
[root@ node1]# nohup kubelet --address=0.0.0.0 \
--port=10250 --logtostderr=true --v=0 \
--api-servers=http://192.168.11.10:8080 >> /var/log/kubernetes/kubelet.log 2>&1 &
[root@ node1]# nohup kube-proxy --logtostderr=true --v=0 --master=http://192.168.11.10:8080 >> /var/log/kubernetes/proxy.log 2>&1 &
```
----------------------------------------------------
### node2: 192.168.11.30
``` bash
[root@ node2]# ls /opt/source
flannel   kubernetes
[root@ node2]# ln -s /opt/source/etcd/etcd  /usr/local/bin
[root@ node2]# ln -s /opt/source/etcd/etcdctl /usr/local/bin
[root@ node2]# ln -s /opt/source/flannel/flanneld /usr/local/bin
[root@ node2]# ln -s /opt/source/kubernetes/server/bin/kubelet /usr/local/bin
[root@ node2]# ln -s /opt/source/kubernetes/server/bin/kube-proxy /usr/local/bin

a.[root@ node2]# mkdir /var/log/{flanneld,kubernetes}

b.[root@ node2]# nohup flanneld -etcd-endpoints=http://192.168.11.10:4001 -remote=192.168.11.10:8888 >> /var/log/flanneld/flanneld.log 2>&1 &

c.[root@ node2]# source /run/flannel/subnet.env

d.[root@ node2]# cat /run/flannel/subnet.env 
FLANNEL_NETWORK=10.1.0.0/16
FLANNEL_SUBNET=10.1.77.1/24
FLANNEL_MTU=1472
FLANNEL_IPMASQ=false

e.[root@ node2]# grep "bip" /lib/systemd/system/docker.service 
ExecStart=/usr/bin/dockerd --bip=10.1.77.1/24 --mtu=1472

f.[root@ node2]# systemctl daemon-reload && systemctl start docker

g.[root@ node2]# ip a|egrep "docker|flan"
3: flannel0: <POINTOPOINT,MULTICAST,NOARP,UP,LOWER_UP> mtu 1472 qdisc pfifo_fast state UNKNOWN qlen 500
    inet 10.1.77.0/16 scope global flannel0
4: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN 
    inet 10.1.77.1/24 scope global docker0
    
### 最后启动kubernetes节点服务：
[root@ node2]# nohup kubelet --address=0.0.0.0 \
--port=10250 --logtostderr=true --v=0 \
--api-servers=http://192.168.11.10:8080 >> /var/log/kubernetes/kubelet.log 2>&1 &
[root@ node2]# nohup kube-proxy --logtostderr=true --v=0 --master=http://192.168.11.10:8080 >> /var/log/kubernetes/proxy.log 2>&1 &


``` 

## 最后查看节点状态
[root@ master] kubectl get nodes
NAME       STATUS    AGE
node1      Ready     1h
node2      Ready     39m
