---
title: django
date: 2017-11-07 01:31:48
update: 2017-11-07 01:31:48
categories: django
tags: django
---
### Mac OS
```
You installed python
You did brew install mysql
You did export PATH=$PATH:/usr/local/mysql/bin
And finally, you did pip install MySQL-Python

```
<!-- more -->

### CentOS 7.2

```
yum install -y epel-release
yum install -y python-pip
pip install django
yum install python-devel gcc gcc-c++ 
pip install python-mysql

```
### 数据库
- [Yum 源安装](https://dev.mysql.com/downloads/repo/yum/)

```
yum install -y mysql57-community-release-el7-11.noarch.rpm
yum install mysql-server

首次启动修改密码:
查看启动日志 找到初始密码
# mysql -hlocalhost -uroot -p
mysql> set password for 'root'@'localhost'=password('password');
mysql> create database test;
mysql> grant all privileges on test.* to 'test'@'%' identified by 'password';

```

## 创建项目
```
mkdir django 
cd django/ 
django-admin.py startproject spark 
cd spark/ 
python manage.py startapp app_web


python manage.py makemigrations
python manage.py migrate

python manage.py createsuperuser

```


## Python manage.py help 帮助命令
- [官方文档说明](https://docs.djangoproject.com/en/1.11/ref/django-admin/)

```

➜ python manage.py help

[auth]
    changepassword
    createsuperuser

[contenttypes]
    remove_stale_contenttypes

[django]
    check
    compilemessages
    createcachetable
    dbshell
    diffsettings
    dumpdata
    flush
    inspectdb
    loaddata
    makemessages
    makemigrations
    migrate
    sendtestemail
    shell
    showmigrations
    sqlflush
    sqlmigrate
    sqlsequencereset
    squashmigrations
    startapp
    startproject
    test
    testserver

[sessions]
    clearsessions

[staticfiles]
    collectstatic
    findstatic
    runserver
```



[中文文档1.8.1](http://python.usyiyi.cn/translate/django_182/intro/tutorial01.html)

