---
title: nginx status 状态信息查看
date: 2017-01-23 16:11:17
update: 2017-01-23 16:11:17
categories: nginx
tags: nginx
---
#
<!-- more -->

``` bash
# cat status.conf 
server {
        listen 80;
        server_name 127.0.0.1;

        location /nginx_status {
               stub_status on;
             access_log off;
              allow 127.0.0.1;
            #  deny all;
        }
}
# service nginx start
# curl http://127.0.0.1/nginx_status
Active connections: 5 
server accepts handled requests
 374869 374869 377429 
Reading: 0 Writing: 1 Waiting: 4 



```
active connections – 活跃的连接数量
server accepts handled requests — 总共处理了374869个连接 , 成功创建377429 次握手, 总共处理了374869个请求
reading — 读取客户端的连接数.
writing — 响应数据到客户端的数量
waiting — 开启 keep-alive 的情况下,这个值等于 active – (reading+writing), 意思就是 Nginx 已经处理完正在等候下一次请求指令的驻留连接.
