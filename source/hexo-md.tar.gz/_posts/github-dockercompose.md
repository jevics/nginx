---
title: gitlab 中文汉化社区版 - docker-compose
date: 2017-01-23 16:03:23
update: 2017-01-23 16:03:23
categories: docker
tags: [docker,gitlab]
---

* docker pull twang2218/gitlab-ce-zh:latest
<!-- more -->
## docker-compose.yml
``` bash
version: '2'
services:
    gitlab:
      image: 'twang2218/gitlab-ce-zh:latest'
      restart: unless-stopped
      hostname: 'gitlab.example.com'
      environment:
        TZ: 'Asia/Shanghai'
        GITLAB_OMNIBUS_CONFIG: |
          external_url 'http://gitlab.example.com'
          gitlab_rails['time_zone'] = 'Asia/Shanghai'
          # 需要配置到 gitlab.rb 中的配置可以在这里配置，每个配置一行，注意缩进。
          # 比如下面的电子邮件的配置：
          # gitlab_rails['smtp_enable'] = true
          # gitlab_rails['smtp_address'] = "smtp.exmail.qq.com"
          # gitlab_rails['smtp_port'] = 465
          # gitlab_rails['smtp_user_name'] = "xxxx@xx.com"
          # gitlab_rails['smtp_password'] = "password"
          # gitlab_rails['smtp_authentication'] = "login"
          # gitlab_rails['smtp_enable_starttls_auto'] = true
          # gitlab_rails['smtp_tls'] = true
          # gitlab_rails['gitlab_email_from'] = 'xxxx@xx.com'
      ports:
        - '80:80'
        - '443:443'
        - '2222:22'
      volumes:
        - config:/etc/gitlab
        - data:/var/opt/gitlab
        - logs:/var/log/gitlab
volumes:
    config:
    data:
    logs:


[root@ gitlab]# docker-compose up -d
Creating network "gitlab_default" with the default driver
Creating volume "gitlab_data" with default driver
Creating volume "gitlab_config" with default driver
Creating volume "gitlab_logs" with default driver
Creating gitlab_gitlab_1
[root@ gitlab]# docker volume ls
DRIVER              VOLUME NAME
local               22158243149a752bd38eafecfc97ac26de0473015b859a147e5a76479ff42d43
local               66c4b034256f096484db155b3c19ad02cef5d4259b94c06211e06f906ad14a1d
local               8012a46744957028029ef0146a512913c491e2bb5acdf76622dc23e53a90fc0c
local               8ce6fc27ee97aa23d1ec279fff1f632d50f97656c6fe2b04817747c3ac842e30
local               gitlab_config
local               gitlab_data
local               gitlab_logs
local               localtime
[root@ gitlab]# netstat -tnlp|grep docker
tcp6       0      0 :::2222                 :::*                    LISTEN      21162/docker-proxy  
tcp6       0      0 :::80                   :::*                    LISTEN      21153/docker-proxy  
tcp6       0      0 :::443                  :::*                    LISTEN      21144/docker-proxy

```
![这里写图片描述](http://img.blog.csdn.net/20170118164426806?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvenhmXzY2ODg5OQ==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
![这里写图片描述](http://img.blog.csdn.net/20170118164441057?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvenhmXzY2ODg5OQ==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)


## [github 仓库地址](https://hub.docker.com/r/twang2218/gitlab-ce-zh/)


