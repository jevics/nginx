---
title: kubernetes SkyDNS
date: 2017-01-23 17:10:33
update: 2017-01-23 17:10:33
categories: kubernetes
tags: kubernetes
---

## skyDNS 
- kubernetes可以为pod提供dns内部域名解析服务。
- 其主要作用是为pod提供可以直接通过service的名字解析为对应service的ip的功能！
<!-- more -->


- **首先在各节点的kubelet 进程中添加选项：**
KUBELET_ARGS="*--cluster_dns=10.254.0.10 --cluster_domain=kube.local*"


### Master 节点操作如下
``` bash
[root@ master /root/yaml]# cat dns/kubedns-rc.yaml  
kind: ReplicationController   
metadata:    
  name: kube-dns-v6
  namespace: default   
  labels:  
    k8s-app: kube-dns
    version: v6
    kubernetes.io/cluster-service: "true"
spec:
  replicas: 1   
    version: v6 
  template:
    metadata:
      labels:
        k8s-app: kube-dns
        version: v6
        kubernetes.io/cluster-service: "true"
    spec:
      containers:
      - name: etcd  
        image: index.tenxcloud.com/google_containers/etcd:2.0.9
        command:
        - /usr/local/bin/etcd
        - -listen-client-urls
        - http://0.0.0.0:2379,http://0.0.0.0:4001
        - -advertise-client-urls
        - http://127.0.0.1:2379,http://127.0.0.1:4001
      - name: kube2sky
        image: index.tenxcloud.com/google_containers/kube2sky:1.11
        resources:
          limits:
            cpu: 100m
            memory: 50Mi
        command:
        - /kube2sky
        - --kube_master_url=http://192.168.11.10:8080
        - -domain=kube.local
      - name: skydns
        image: index.tenxcloud.com/google_containers/skydns:2015-03-11-001
        resources:
        command:
        - /skydns
        - -machines=http://localhost:4001
        - -addr=0.0.0.0:53
        - -domain=kube.local
        ports:
        - containerPort: 53
          name: dns
          protocol: UDP
        - containerPort: 53
          name: dns-tcp
          protocol: TCP
      dnsPolicy: Default

[root@ master yaml]# cat dns/kubedns-service.yaml 
apiVersion: v1 
kind: Service
metadata:
  name: kube-dns  
  namespace: default
  labels:
    k8s-app: kube-dns
    kubernetes.io/cluster-service: "true"
    kubernetes.io/name: "KubeDNS"
spec:
  selector:  
    k8s-app: kube-dns
  clusterIP: 10.254.0.10
  ports:
  - name: dns
    port: 53
    protocol: UDP
  - name: dns-tcp
    port: 53
    protocol: TCP
```
### 注意：　
- pause负责管理pod的网络等相关事务: gcr.io/google_containers/pause-amd64:3.0)
- 谷歌被墙了，可以通过以下方式来使用：
- 1.翻墙或访问国内的docker镜像站点,下载下来改名
``` bash
[root@ master yaml]# docker pull mritd/pause-amd64:3.0
[root@ master yaml]# docker tag mritd/pause-amd64:3.0 gcr.io/google_containers/pause-amd64:3.0
```
- 2.使用内部私有仓库,在各k8s节点的kubelet 服务进程添加下面参数：
"--pod-infra-container-image=my.hub.io/pause-amd64:3.0" 

#### node 节点镜像列表 [实际环境中建议使用私有仓库的镜像]
``` bash 
[root@ node1]# docker images       // (显示内容便于查看,所以不完整)
gcr.io/google_containers/pause-amd64             3.0                 
index.tenxcloud.com/google_containers/kube2sky   1.11      
index.tenxcloud.com/google_containers/etcd       2.0.9   
index.tenxcloud.com/google_containers/skydns     2015-03-11-001  
[root@ master yaml]# kubectl create -f dns/kubedns-rc.yaml --validate  //检查文件的正确性并创建
[root@ master yaml]# kubectl create -f dns/kubedns-service.yaml
[root@ master yaml]# kubectl get rc
NAME          DESIRED   CURRENT   AGE
kube-dns-v6   1         1         38m
[root@ master yaml]# kubectl get svc
NAME            CLUSTER-IP       EXTERNAL-IP   PORT(S)         AGE
kube-dns        10.254.0.10      <none>        53/UDP,53/TCP   38m
kubernetes      10.254.0.1       <none>        443/TCP         5h
[root@ master yaml]# kubectl get svc -o wide    // -o wide 参数显示详细信息
NAME            CLUSTER-IP      EXTERNAL-IP   PORT(S)         AGE       SELECTOR
kube-dns        10.254.0.10     <none>        53/UDP,53/TCP   2d        k8s-app=kube-dns
kubernetes      10.254.0.1      <none>        443/TCP         3d        <none>
```

### 测试DNS 是否正常解析：
- 首先分别创建一个名为：mysql-service的service 和 busybox的pod 
``` bash
[root@ master yaml]# cat mysql-server.yaml 
apiVersion: v1
kind: Service
metadata:
  labels:
    name: mysql
    role: service
  name: mysql-service
spec:
  type: NodePort    
  ports:
    - port: 3306  
      targetPort: 3306 
      nodePort: 31000 
  selector:
    name: mysql
[root@ master yaml]# cat busybox.yaml 
apiVersion: v1
kind: Pod
metadata:
  labels:
    name: busybox
    role: master
  name: busybox
spec:
  containers:
    - name: busybox
      image: busybox  
      command:
      - sleep
      - "360000"
[root@ master yaml]# kubectl create -f mysql-server.yaml
[root@ master yaml]# kubectl create -f busybox.yaml
[root@ master yaml]# kubectl get svc
NAME            CLUSTER-IP       EXTERNAL-IP   PORT(S)         AGE
kube-dns        10.254.0.10      <none>        53/UDP,53/TCP   41m
kubernetes      10.254.0.1       <none>        443/TCP         5h
mysql-service   10.254.155.188   <nodes>       3306/TCP        41m
[root@ master yaml]# kubectl get pod -o wide
NAME                READY     STATUS    RESTARTS   AGE       IP          NODE
busybox             1/1       Running   0          2d        10.1.77.2   node1
kube-dns-v6-dfucv   3/3       Running   0          2d        10.1.62.2   node2
[root@ master yaml]# kubectl exec -i -t busybox sh
/ # nslookup mysql-service
Server:    10.254.0.10
Address 1: 10.254.0.10

Name:      mysql-service
Address 1: 10.254.155.188
/ # nslookup mysql-service.default.kube.local
Server:    10.254.0.10
Address 1: 10.254.0.10

Name:      mysql-service.default.kube.local
Address 1: 10.254.155.188
/ #  nslookup mysql-service.default.svc.kube.local
Server:    10.254.0.10
Address 1: 10.254.0.10

Name:      mysql-service.default.svc.kube.local
Address 1: 10.254.155.188
```

> 可以看到mysql-service、mysql-service.default.svc.kube.local、mysql-service.default.kube.local的域名均能正确解析为mysql-service的service中的 10.254.155.188。
mysql-service.default.kube.local为完整域名，其组成为[service-name].[namespace].[domain-name]
~ 扩展命令操作<更多命令操作请kubectl --help 或访问 [官方kubectl命令手册](http://kubernetes.io/docs/user-guide/kubectl-overview/)>
kubectl get rc --namespace=kube-system   查询指定命名空间
kubectl get pod --all-namespaces=true   查询所有命名空间    


### 最后在简单介绍下kubernetes dns的原理:
首先在部署时候创建了一个dns的rc，最终会产生三个容器(不含pause)
``` bash
[root@ node2 ]# docker ps -a   // 根据上面的 kubectl get pod -o wide  运行在node2 节点
CONTAINER ID        IMAGE                                            COMMAND                  CREATED              STATUS              PORTS               NAMES
033800f393b9        index.alauda.cn/tutum/centos:centos6             "/run.sh"                3 days ago           Up 3 days           22/tcp              awesome_newton
0fb60dcfb8b4        gcr.io/google_containers/etcd:2.0.9              "/usr/local/bin/etcd "   3 days ago           Up 3 days                               k8s_etcd.8d001f7f_kube-dns-v6-ju8cb_default_149fdba5-4e50-11e6-ba47-0800273d5f3f_6afe5c27
0a0efd5f0aaa        gcr.io/google_containers/skydns:2015-03-11-001   "/skydns -machines=ht"   3 days ago           Up 3 days                               k8s_skydns.5d0f4a29_kube-dns-v6-ju8cb_default_149fdba5-4e50-11e6-ba47-0800273d5f3f_f7c4ee06
cfef318e4032        gcr.io/google_containers/kube2sky:1.11           "/kube2sky --kube_mas"   3 days ago           Up 3 days                               k8s_kube2sky.eb7ac18c_kube-dns-v6-ju8cb_default_149fdba5-4e50-11e6-ba47-0800273d5f3f_19b79770
afad7b2ebd3d        docker.io/kubernetes/pause                       "/pause"                 3 days ago           Up 3 days                               k8s_POD.87e723e6_kube-dns-v6-ju8cb_default_149fdba5-4e50-11e6-ba47-0800273d5f3f_3c3f7c87
```
### dns解析过程
在创建的pod中，可以查看其所使用的域名解析服务器:
``` bash
[root@master ]# kubectl exec -i -t busybox sh
/ # cat /etc/resolv.conf 
search default.svc.kube.local svc.kube.local kube.local 
nameserver 10.254.0.10
options ndots:5
```
在kubelet创建pod时，会使用为kubelet配置的
``` bash
-cluster_dns=10.254.0.10 --cluster_domain=kube.local
```

 - 在创建的pod中从而使用对应的dns服务器
   而这一dns解析服务，实际是由dns的rc中的gcr.io/google_containers/skydns:2015-03-11-001容器0a0efd5f0aaa完成的。
   skydns的数据源来自于gcr.io/google_containers/etcd:2.0.9的容器0fb60dcfb8b4。

``` bash
[root@ node2 ]# docker exec -it 0fb etcdctl get /skydns/local/kube/svc/default/mysql-service/2f1020d6
{"host":"10.254.162.44","priority":10,"weight":10,"ttl":30,"targetstrip":0}
[root@ node2]# docker exec -it 0fb etcdctl get /skydns/local/kube/default/mysql-service
{"host":"10.254.162.44","priority":10,"weight":10,"ttl":30,"targetstrip":0}
```

### service同步过程

 - etcd的数据源自于gcr.io/google_containers/kube2sky:1.11创建的cfef318e4032容器。
   cfef318e4032容器通过watch kube-api的service，查看service的变化。
   当service创建/删除/修改时，cfef318e4032容器获取对应的service信息，将其保存在etcd的容器0fb60dcfb8b4中，进而提供给skydns使用

