---
title: Python SSH 批量执行命令(paramiko模块)
date: 2017-07-21 08:16:45
update: 2017-07-21 08:16:45
categories: Python
tags: Python
---

paramiko模块是基于python实现了SSH2远程安全连接，支持认证和密钥方式，可以实现远程连接、命令执行、文件传输、中间SSH代理功能
<!-- more -->

## 基于密钥认证的SSH 批量连接操作
``` python
#!/usr/bin/env python
# coding: utf-8
import paramiko
import threading
import sys


def SSH2(ip, cmd):
    hostname = ip
    port = 22
    username = 'root'
    key_file = '/root/.ssh/id_rsa'
    key = paramiko.RSAKey.from_private_key_file(key_file)
    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(hostname, port, username, pkey=key)
        stdin, stdout, stderr = s.exec_command(cmd)
        print stdout.read()
        print "%s\tOK\n" % ip
        s.close()
    except Exception, e:
        print e
        sys.exit(1)

def cmd(ip, cmd):
    '''
    开启多线程
    '''
    threads = []
    Cmd = threading.Thread(target=SSH2, args=(ip, cmd))
    Cmd.start()


#cmd('192.168.1.1','df -h')

```
