---
title: LogUploadTest for Python
date: 2017-04-01 15:07:18
update: 2017-04-01 15:07:18
categories: Python
tags: Python
---

## LogsUpload test Scripts
<!-- more-->

## ConfigFiles
``` bash
[config]
hdfs = 192.168.1.10:50070
hpath = /logs/test/mins
user = dbuser
host = 192.168.1.1
passwd = password
database = loguser
email = admin@jevic.com
Mins = 0 5 10 15 20 25 30 35 40 45 50 55
Domains = jevic.github.io www.jevic.cn

```

## LoggerConfig

``` bash
###############################################
[loggers]
keys=root,logupload
[logger_root]
level=WARN
handlers=hand01
[logger_logupload]
level=INFO
handlers=hand01
qualname=logupload
propagate=0
###############################################
[handlers]
keys=hand01
[handler_hand01]
class=handlers.RotatingFileHandler
level=INFO
formatter=form01
args=('logs/upload.log', 'a', 10*1024*1024, 5)
###############################################
[formatters]
keys=form01
[formatter_form01]
format=%(asctime)s %(levelname)s %(message)s
datefmt=%a, %d %b %Y %H:%M:%S

```

## SendMailsConfig

``` bash
#!/usr/bin/python
# coding: utf-8
import smtplib
from email.MIMEText import MIMEText
from email.Header import Header
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

def send_mail(toMail, subject, body):
    smtpHost = 'smtp.163.com'
    smtpPort = '25'
    
    fromMail = "test@163.com"
    username = "test"
    password = "passwd"
    encoding = 'utf-8'
    toMail=toMail.split(',')

    mail = MIMEText(body.encode(encoding),'plain',encoding)
    mail['Subject'] = Header(subject, encoding)
    mail['From'] = fromMail
    mail['To'] =",".join(toMail) 
    try:
        smtp = smtplib.SMTP(smtpHost, smtpPort, timeout=20)
        smtp.ehlo()
        smtp.login(username, password)
        smtp.sendmail(fromMail, toMail, mail.as_string())
        smtp.close()
    except Exception, data:
        print  Exception, ":", data
        print 'Error: unable to send email'
        return False
        
    return True

```

## Main

``` bash
#!/usr/bin/python
# coding: utf-8
import time
import datetime
import sys
import os
import logging
import logging.config
import ConfigParser
import mysql.connector
from pyhdfs import HdfsClient
from os.path import getsize
from mail_oss import send_mail

'''
Check logs upload
'''


Sdir = os.path.split(os.path.realpath(sys.argv[0]))[0]
os.chdir(Sdir)
# reload logs config
logging.config.fileConfig("logger.conf")
logger = logging.getLogger("logupload")
# reload config files
Vals = ConfigParser.ConfigParser()
Vals.read('config.cfg')

### hdfs
HdfsAddr = Vals.get("config","hdfs")
HdfsPath = Vals.get("config","hpath")
Client = HdfsClient(hosts = HdfsAddr)
email = Vals.get("config","email")
### oss
bucket = "oss://logs/user"
### mysql
muser = Vals.get("config","user")
mpass = Vals.get("config","passwd")
mhost = Vals.get("config","host")
mdb = Vals.get("config","database")
### domain_list and mins
domain = Vals.get("config","Domains").split()
mins = Vals.get("config","Mins").split()
#### init mysql
db = mysql.connector.connect(user=muser,host=mhost,password=mpass,database=mdb)
cursor = db.cursor()


def color_print(msg, color='red', exits=False):
    """
    Print colorful string.
    """
    color_msg = {'blue': '\033[1;36m%s\033[0m',
                 'green': '\033[1;32m%s\033[0m',
                 'yellow': '\033[1;33m%s\033[0m',
                 'red': '\033[1;31m%s\033[0m',
                 'title': '\033[30;42m%s\033[0m',
                 'info': '\033[32m%s\033[0m'}

    msg = color_msg.get(color, 'red') % msg
    return msg
    if exits:
       time.sleep(2)
       sys.exit()

def bash(cmd):
    '''
    run command
    '''
    return os.popen(cmd).read().strip()

class formatDate(object):
    '''
    Format Date
    '''
    hh = 2
    def Set_hour(self, newhour):
        self.hh = newhour

    def Set_strp(self):
        Ago2 = (datetime.datetime.now() - datetime.timedelta(hours=self.hh))
        A2sp = time.strptime(Ago2.ctime(), "%a %b %d %H:%M:%S %Y")
        return A2sp

    def get_hpath(self):
        return time.strftime("%Y%m%d", self.Set_strp())

    def get_ohfiles(self):
        return time.strftime("%Y_%m_%d", self.Set_strp())

    def get_opath(self):
        return time.strftime("%Y-%m-%d", self.Set_strp())

    def get_hour(self):
        return time.strftime("%H", self.Set_strp())

    def get_times(self, mins):
        Ago2 = (datetime.datetime.now() - datetime.timedelta(hours=self.hh))
        A2day = time.strftime("%Y-%m-%d", self.Set_strp())
        A2hour = time.strftime("%H", self.Set_strp())
        A2list = Ago2.ctime().split(' ', 5)
        Ctime = str(time.mktime(time.strptime("%s %s %s %s:%s:%s %s" % (A2list[0], A2list[1], A2list[2], A2hour, mins, 0, A2list[-1]),"%a %b %d %H:%M:%S %Y"))).split('.',5)[0]
        return Ctime


def CheckOssUpload():
    for mas in domain:
        dfile = "%s_%s_%s%s_%s" % (mas,hdate.get_ohfiles(),hdate.get_hour(),min,'0.gz')
        fpath = "%s%s/%s%s/%s" % (HdfsPath,hdate.get_hpath(),hdate.get_hour(),min,dfile)
        try:
            ### 
            logger.info('Step.1 Check HdfsFiles %s' % dfile)
            if Client.list_status("%s%s/%s%s/%s_%s_%s%s_%s" % (HdfsPath, hdate.get_hpath(), hdate.get_hour(), min, mas, hdate.get_ohfiles(), hdate.get_hour(), min,'0.gz')):
                logger.info(color_print('%s : %s' % ('HdfsFiles OK --', dfile), 'info'))
                ### 
                logger.info('Step.2 Check OssFiles')
                ossExe = "%s %s %s %s/%s/%s%s %s %s %s" % ('aliyuncli','oss','List',bucket,hdate.get_opath(),hdate.get_hour(),min,'2>/dev/null|grep',mas,'|wc -l')
                ossCheck = bash('%s' % ossExe)
                Prefix = "%s/%s/%s%s/%s_%s_%s_%s%s" % ('logs', hdate.get_opath(), hdate.get_hour(), min, mas, hdate.get_ohfiles(), hdate.get_hour(), min,'.gz')
        	oval = int(ossCheck)
                if oval == 0:
                    ### 
                    logger.info(color_print('Download HDFS files : %s' % (dfile), 'info'))
                    Client.copy_to_local(fpath, dfile)
                    ### 
                    bash("%s %s %s %s %s/%s/%s%s/%s_%s_%s_%s%s" % ('aliyuncli', 'oss', 'Put', dfile, bucket, hdate.get_opath(), hdate.get_hour(), min, mas,hdate.get_ohfiles(), hdate.get_hour(), min, '.gz'))
                    logger.info(color_print('Upload to oss files: %s' % (Prefix), 'info'))
                    putlist = "%s %s %s %s %s/%s/%s%s/%s_%s_%s_%s%s" % ('aliyuncli', 'oss', 'Put', dfile, bucket, hdate.get_opath(), hdate.get_hour(), min, mas,hdate.get_ohfiles(), hdate.get_hour(), min, '.gz')
                    logger.info(putlist)
                    ### 
                    Ctimes = hdate.get_times(min)
                    Ntime = bash('%s %s%s' % ('date', '+', '%s'))
                    Length = os.path.getsize('%s' % dfile)
                    ### 
                    sql = "insert into test(bucket,prefix,host,timestamp,create_time,length,mtype,content_length) values('%s','%s','%s','%s','%s','%s','%s','%s')" % ('ngx-log', Prefix, mas, Ctimes, Ntime, 5, 0, Length)
                    try:
                        logger.info(sql)
                        cursor.execute(sql)
                        db.commit()
                        os.remove(dfile)
                    except Exception,e3:
                        logger.error(e3)
                        db.rollback()
            send_mail(email,'error',e3)
                        sys.exit(102)
                else:
                    logger.warn(color_print('%s : %s' % ('OSS Files Already Exist', Prefix), 'yellow'))
                    continue
        except:
            logger.warn(color_print('HDFS File Not Exist : %s' % (dfile), 'yellow'))
            continue

if __name__ == "__main__":
    hdate = formatDate()
    for ss in mins:
        mi = int(ss)
        min = "%02d" % mi
        Sfile = ("%s%s/%s%s/%s" % (HdfsPath, hdate.get_hpath(), hdate.get_hour(), min, '_SUCCESS'))
        logger.info(color_print('Check Files: %s' % (Sfile), 'title'))
        try:
            if Client.list_status(Sfile):
                CheckOssUpload()
        except Exception, e:
            logger.error(color_print('%s' % e))
        send_mail(email,'HDFS error',e)
            sys.exit(13)    
    db.close()



```


