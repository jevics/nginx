---
title: Redis 模块
date: 2017-08-08 19:29:01
update: 2017-08-08 19:29:01
categories: Python
tags: Python
---

![](http://2sharings.com/files/uploads/2015/05/redis-logo.png)
<!-- more -->

## redis

```
#!/usr/bin/python
# coding: utf-8
import redis

pool = redis.ConnectionPool(host='localhost', port=6379, db=0)
RedisClient = redis.Redis(connection_pool=pool)


def SetKey(Name,Rkey):
    RedisClient.set(Name,Rkey)
    print RedisClient.get(Name)

def HsetKey(Name,Rkey,Value):
    RedisClient.hset(Name,Rkey,Value)
    print RedisClient.hgetall(Name)


```


## 订阅发布
```
#!/usr/bin/python
# coding: utf-8
import redis

class RedisHelper:
      def __init__(self):
        self.__conn = redis.Redis(host='localhost')
        self.chan_sub = 'fm104.3'
        self.chan_pub = 'fm104.3'
      def public(self,msg):
        self.__conn.publish(self.chan_pub,msg)
        return True
      def subscribe(self):
        pub = self.__conn.pubsub()
        pub.subscribe(self.chan_sub)
        pub.parse_response()
        return pub

[root@master redis]# cat subscriber.py
#!/usr/bin/python
# coding: utf-8
# 订阅者
from monitor import RedisHelper

obj = RedisHelper()
redis_sub = obj.subscribe()

while True:
    msg = redis_sub.parse_response()
    print msg

[root@master redis]# cat announcer.py
#!/usr/bin/python
# coding:utf-8
# 发布者

from monitor import RedisHelper

obj = RedisHelper()
obj.public('hello')


```

- [Github](https://github.com/WoLpH/redis-py)
- [pypi](https://pypi.python.org/pypi/redis/)
