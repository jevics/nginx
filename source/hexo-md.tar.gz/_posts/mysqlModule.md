---
title: Python Mysql模块
date: 2017-05-16 22:35:18
update: 2017-05-16 22:35:18
categories: Python
tags: Python
---

Mysql Python操作接口模块
<!-- more -->

``` bash

#!/usr/bin/python
# coding: utf-8
import mysql.connector

db = mysql.connector.connect(user='USERNAME',host='192.168.1.1',password='PASSWORD',database='test')

cursor = db.cursor()

# 如果数据表已经存在使用 execute() 方法删除表。
#cursor.execute("DROP TABLE IF EXISTS EMPLOYEE")

# 创建数据表SQL语句
sql = """CREATE TABLE EMPLOYSS (
         FIRST_NAME  CHAR(20) NOT NULL,
         LAST_NAME  CHAR(20),
         AGE INT,  
         SEX CHAR(1),
         INCOME FLOAT )"""

cursor.execute(sql)

# 关闭数据库连接
db.close()



# SQL 插入语句
sql = """INSERT INTO EMPLOYEE(FIRST_NAME,
         LAST_NAME, AGE, SEX, INCOME)
         VALUES ('Mac', 'Mohan', 20, 'M', 2000)"""
try:
   # 执行sql语句
   cursor.execute(sql)
   # 提交到数据库执行
   db.commit()
except:
   # Rollback in case there is any error
   db.rollback()

# 关闭数据库连接
db.close()


```


## MySQL查询

``` 
import mysql.connector

#### init mysql
db = mysql.connector.connect(user=muser,host=mhost,password=mpass,database=mdb)
cursor = db.cursor()
## 查询数据域名列表
cursor.execute('select * from record')
values = cursor.fetchall()
domain = []
for main in range(0,len(values)):
    domain.append(values[main][0])
```
