---
title: python elasticsearch 模块操作记录
date: 2017-08-02 18:13:18
update: 2017-08-02 18:13:18
categories: Python
tags: Python elk
---

## Python elasticsearch 操作
<!-- more -->

## 删除索引数据1

``` python

#!/usr/bin/python
# coding: utf-8
#
from elasticsearch import Elasticsearch
import sys,os

es = Elasticsearch([{'host':'192.168.1.1','prot':80}])

if len(sys.argv) < 2:
   print "文件内容格式: 12:06:39 6aa18dc07c33f91498098392427107"
   print "运行示例: %s %s %s" % (sys.argv[0],'2017.08.02','/path/filename')
   os._exit(1)

try:
    days = sys.argv[1]
    ## 索引
    indices = "indix-%s" % days
    file_path = sys.argv[2]
    dtype = 'logs'
    Files = open(file_path, 'r')
except:
    print "参数错误!"
    print "运行示例: %s %s %s" % (sys.argv[0],'2017.08.02','/path/filename')
    sys.exit(2)

for line in Files.readlines():
    stream1 = line.split(' ')[1]
    Stream = stream1.replace("\n","")
    QuerySQL = {"query": {"match": {"message": "some message"} } }
    try:
         res = es.search(index=indices,doc_type=dtype, body=QuerySQL)
         TimeStamp = res.get('hits').get('hits')[0].get('_source').get('@timestamp')
         ResponseCode = res.get('hits').get('hits')[0].get('_source').get('response_code')
         print 'Time: %s Code: %s Stream: %s' % (TimeStamp,ResponseCode,Stream)
    except Exception,e1:
         print e1
     continue


```

## 删除指定索引数据 2

``` python

#!/usr/bin/python
# coding: utf-8
## 
from datetime import datetime
from elasticsearch import Elasticsearch
import os
import sys
import time
import urllib2

'''
Error: 'ascii' codec can't decode byte 0xef in position 0:ordinal not in range(128)
转换字码为 utf-8 
''' 

reload(sys)
sys.setdefaultencoding('utf-8')

es = Elasticsearch([{'host':'1.1.1.1','prot':80}])
## 索引名称
indices = "indices-"
## 字段类型
dtype = 'logs'
## 
urls = 'http://1.1.1.1:80/'

def bash(cmd):
    return os.popen(cmd).read().strip()

## 传入文件
file_path = sys.argv[1]
Files = open(file_path, 'r')
for line in Files.readlines():
    ## IP 地址
    ip1 = line.split('\t')[1]
    IP = ip1.replace("\n","")
    ## 时间戳
    day1 = line.split('\t')[0]
    day2 = day1.replace('/','-')
    Tday = "%s:00" % day2
    timeArray = time.strptime(Tday, "%Y-%m-%d %H:%M:%S")
    timestamp1 = str(time.mktime(timeArray))
    timestamp = timestamp1.split('.')[0]
    ## 索引时间
    iday = datetime.strptime(Tday,'%Y-%m-%d %H:%M:%S')
    Days = iday.strftime('%Y.%m.%d')
    ## 索引
    Indices = "%s%s" % (indices,Days)
    ## 查询语句
    QueryName = {"query": {"match": {"message": "some message"} } }
    ## 搜索结果
    try:
        res = es.search(index=Indices,doc_type=dtype, body=QueryName)
        ## 获取_id
        num_id = res.get('hits').get('hits')[0].get('_id')
        print "索引: %s 时间戳: %s IP: %s _id: %s" % (Indices,timestamp,IP,num_id)
        ## 删除索引
        URL = "%s%s/%s/%s" % (urls,Indices,dtype,num_id)
        request = urllib2.Request(URL)
        request.get_method = lambda: 'DELETE'
        response = urllib2.urlopen(request)
    except Exception,e1:
        print "-------"
        URL = "%s%s/%s/" % (urls,Indices,dtype)
        print URL
        continue




```
